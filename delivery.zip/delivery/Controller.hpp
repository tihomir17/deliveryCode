#ifndef CONTROLLER_HPP_
#define CONTROLLER_HPP_

namespace Controller
{
  /**
   * \class Controller
   * Derived class of interface IMoneyController, IPresentationLocalhost, IStateMachine, ICbMoneyController and and allows a shared_ptr to the current object to be obtained from within a member function.
   * \brief Thin VLT controller class
   */
  class Controller;

  /**
  * Shared pointer for Controller class
  */
  typedef boost::shared_ptr<Controller> ControllerPtr;

  class Controller: public IController, 
                           public IPresentationLocalhost,
                           public IStateMachine,
                           public ICbMoneyController,
                           public boost::enable_shared_from_this<Controller>
  {
  public:

    /**
     * This method get new instance of Controller
     * \return Controller as ControllerPtr where ControllerPtr is boost::shared_ptr<Controller>
     */
    static ControllerPtr GetInstance();

    /**
     * This method clear instance of Controller
     */
    static void ClearInstance();

    ~Controller();

    /**
     * This method implements the method Init from interface IController to initialize the necessary objects.
     */
    virtual void Init();

    /**
     * This method implements the method Clean from interface IController to clean the required objects.
     */
    virtual void Clean();

    /**
     * This method implements the method Start from interface IController to start required modules.
     */
    virtual void Start(void);

    /**
     * This method implements the method Start from interface IController to stop required modules.
     */
    virtual void Stop(void);

    /**
     * This method should be executed when barcode is read .
     * \param input string
     */
    void KeyboardCallbackFunction(string input);

    /**
     * This method is not implemented
     */
    void PresentationServiceCallback(MessageType& messageType);

    /**
     * This method implements the method GetBalance from interface IPresentationLocalhost to get current balance.
     * \return presentationBalance as PresentationBalancePtr where PresentationBalancePtr is boost::shared_ptr<PresentationBalancePtr>
     */
    virtual PresentationBalancePtr GetBalance();

    /**
     * This method implements the method Cashout from interface IPresentationLocalhost to cashout and print ticket.
     */
    virtual void Cashout();

    /**
     * This method implements the method CheckPresentationMessageStatus from interface IPresentationLocalhost to check presentation message status.
     * \return presentationStatusMessage as PresentationStatusMessagePtr where PresentationStatusMessagePtr is boost::shared_ptr<PresentationStatusMessage>
     */
    virtual PresentationStatusMessagePtr CheckPresentationMessageStatus();

    /**
     * This method implements the method PlayerGame from interface IPresentationLocalhost to invoke play game service operation.
      * \param sessionToken string&
      * \param clientIp string&
      * \param gameId string&
      * \param realPlay string&
      * \return string Parameters required to start game
      */
    virtual string PlayerGame(const string& sessionToken, const string& clientIp, const string& gameId, const string& realPlay);

    /**
     * This method implements the method BalanceZeroCallback from interface ICbMoneyController to be executed when balance is zero.
     */
    virtual void BalanceZeroCallback();

    /**
     * This method implements the method BalanceNotZeroCallback from interface ICbMoneyController to be executed when balance is not zero.
     */
    virtual void BalanceNotZeroCallback();
    /**
     * This method redeems ticket
     */
    void RedeemTicket();
    /**
     * This method navigate VLT Browser to home page
     */
    void NavigateToVLTHomePage();

    /**
     * This method navigate VLT Browser to idle page
     */
    void NavigateToIdlePage();
    
    /**
     * This method implements the method AddEvent from interface IStateMachine to add new event.
     * \param event VLTEvent
     */
    virtual void AddEvent(VLTEvent event);

    /**
     * This method implements the method RunStateMachine from interface IStateMachine to start VLT state machine.
     */
    virtual void RunStateMachine();

    /**
     * This method implements the method StopStateMachine from interface IStateMachine to stop VLT state machine.
     */
    virtual void StopStateMachine();

    /**
     * This method returns shared pointer to the current object of Controller class.
     * \return ControllerPtr where ControllerPtr is boost::shared_ptr<Controller>)
     */
    ControllerPtr GetThis();
  private:
    Controller();
    Controller(Controller &);
    Controller &operator=(Controller &);

    static ControllerPtr s_Controller;
    static boost::mutex s_CsController;

    PlayerDataPtr m_PlayerDataPtr;
    ServiceDataPtr m_ServiceDataPtr;

    IMoneyControllerPtr m_IMoneyControllerPtr;
    IIdentityControllerPtr m_IIdentityControllerPtr;
    
    ITicketServiceClientPtr m_ITicketServiceClientPtr;
    IPresentationMQSPtr m_IPresentationMQSPtr;
    IProdGameServiceClientPtr m_IProdGameServiceClientPtr;

    VLTServerPtr m_VLTServer;
    KeyboardPtr m_Keyboard;
    PrinterPtr m_Printer;
    KeyboardCallbackEventType m_KeyboardCallback;


    stringstream m_BarcodeInput;
    
    string m_PresentationStatus;
    string m_PresentationErrorMessage;
    PresentationStatusMessagePtr m_PresentationStatusMessagePtr;
    
    queue <VLTEvent> queueEvent;
    int m_WaitingForCreditMinutes;
    bool m_FlagStartStateMachine;
  };
}

#endif
