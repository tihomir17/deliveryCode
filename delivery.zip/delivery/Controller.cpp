#include "Controller.hpp"

namespace Controller
{
  static log4cxx::LoggerPtr s_Log = log4cxx::Logger::getLogger("....");

  const char* StartClassSequenceItem="startClassSequence";

  ControllerPtr Controller::s_Controller;
  boost::mutex Controller::s_CsController;

  Controller::Controller()
  {
    VLT_METHOD_TRACE(s_Log, "Controller::Controller()");
  }

  Controller::~Controller(void)
  {
    VLT_METHOD_TRACE(s_Log, "Controller::~Controller()");
  }

  ControllerPtr Controller::GetInstance()
  {
    VLT_METHOD_TRACE(s_Log, "Controller::GetInstance()");

    boost::mutex::scoped_lock _lock(s_CsController);
    if (!s_Controller)
    {
      s_Controller = ControllerPtr(new Controller());
    }
    return s_Controller;
  }

  void Controller::ClearInstance()
  {
    VLT_METHOD_TRACE(s_Log, "Controller::ClearInstance()");
    boost::mutex::scoped_lock _lock(s_CsController);
    s_Controller.reset();
  }

  void Controller::Init()
  {
    VLT_METHOD_TRACE(s_Log, "Controller::Init()");
  
    try
    {
      MessageQueue::RemoveQueueStatic();
      m_PlayerDataPtr = PlayerDataPtr(new PlayerData());
      m_ServiceDataPtr = ServiceDataPtr(new ServiceData());
      m_PlayerDataPtr->SetPlayerId(boost::lexical_cast<long>(AppConfig::GetInstance().GetConfigurationItem("PlayerData.playerId")));

      m_ITicketServiceClientPtr = ITicketServiceClientPtr(new TicketServiceClient());
      m_IProdGameServiceClientPtr = IProdGameServiceClientPtr(new ProdGameServiceClient());

      m_IMoneyControllerPtr = IMoneyControllerPtr(new MoneyController((boost::dynamic_pointer_cast<ICbMoneyController>(GetThis())), m_PlayerDataPtr, m_ServiceDataPtr));
      m_IMoneyControllerPtr->Init();
      m_IIdentityControllerPtr = IIdentityControllerPtr(new IdentityController(m_PlayerDataPtr, m_ServiceDataPtr));
      m_IIdentityControllerPtr->Init();

      m_KeyboardCallback = KeyboardCallbackEventType(boost::bind(&Controller::KeyboardCallbackFunction,GetThis(),_1));
      m_Keyboard = KeyboardPtr(new Keyboard(m_KeyboardCallback));
      m_Keyboard->Init();
      m_Printer = PrinterPtr(new Printer());
      m_Printer->Init();

      m_VLTServer = VLTServerPtr(new VLTServer(boost::dynamic_pointer_cast<IPresentationLocalhost>(GetThis())));

      m_IPresentationMQSPtr = IPresentationMQSPtr(new PresentationMQS());
      m_IPresentationMQSPtr->SetReceiveCallback(boost::bind(&Controller::PresentationServiceCallback,GetThis(),_1));
      m_PresentationStatusMessagePtr = PresentationStatusMessagePtr(new PresentationStatusMessage());

      m_WaitingForCreditMinutes = boost::lexical_cast<int>(AppConfig::GetInstance().GetConfigurationItem("StateMachine.WaitingForCreditMinutes"));

      m_PresentationStatus = PresentationStatusMessage::STATUS_SUCCESS;

      LOG4CXX_INFO(s_Log, "Host IP Address = " << m_ServiceDataPtr->GetClientIpAddress());
    }
    catch(BaseException& ex)
    {
      LOG4CXX_ERROR(s_Log, ex.GetErrorMessage());
      throw VLTControllerException(VLTControllerException::ERR_VLTCONTROLLER_INIT);
    }
  }

  void Controller::Clean()
  {
    m_PlayerDataPtr.reset();
    m_ServiceDataPtr.reset();
    m_IMoneyControllerPtr.reset();
    m_IIdentityControllerPtr.reset();
    m_ITicketServiceClientPtr.reset();
    m_IProdGameServiceClientPtr.reset();
    m_Keyboard.reset();
    m_Printer.reset();
    m_VLTServer.reset();
    m_IPresentationMQSPtr.reset();
    m_PresentationStatusMessagePtr.reset();
  }

  void Controller::Start(void)
  {
    VLT_METHOD_TRACE(s_Log, "Controller::Start()");

    try
    {
      m_IMoneyControllerPtr->Start();
      m_Keyboard->Start();
      m_VLTServer->Start();
      m_IPresentationMQSPtr->StartMessageQueueReceiving();
      RunStateMachine();
    }
    catch(BaseException& ex)
    {
      LOG4CXX_INFO(s_Log, ex.GetMsgId());
      throw VLTControllerException(VLTControllerException::ERR_START_CONTROLLER);
    }
  }

  void Controller::Stop(void)
  {
    VLT_METHOD_TRACE(s_Log, "Controller::Stop()");

    try
    {
      m_IMoneyControllerPtr->Stop();
      m_Keyboard->Stop();
      m_VLTServer->Stop();
      m_IPresentationMQSPtr->StopMessageQueueReceiving();
      StopStateMachine();
    }
    catch(BaseException& ex)
    {
      LOG4CXX_INFO(s_Log, ex.GetMsgId());
      throw VLTControllerException(VLTControllerException::ERR_STOP_CONTROLLER);
    }
  }

  PresentationBalancePtr Controller::GetBalance()
  {
    PresentationBalancePtr presentationBalance(new PresentationBalance());
    BalancePtr balance = m_IMoneyControllerPtr->GetBalance();
    presentationBalance->SetAmount(balance->GetCreditCash());
    presentationBalance->SetCurrency(balance->GetCurrency());

    return presentationBalance;
  }

  void Controller::Cashout()
  {

    try
    {
      int printStatus;
      TicketInfoPtr ticketInfo = m_IMoneyControllerPtr->CreateTicketAndTransferMoney();
      
      TicketBufferPtr ticketBuffer = m_ITicketServiceClientPtr->GenerateTicket(ticketInfo);

      int jobId = m_Printer->PrintStream(ticketBuffer->GetBuffer());

      while((printStatus=m_Printer->CheckPrintingStatus(jobId))!=IPP_JOB_COMPLETED)
      {
        sleep(1);
      }

      AddEvent(CashoutEvent);
    }
    catch(MoneyControllerException& ex)
    {
      LOG4CXX_ERROR(s_Log, ex.GetMsgId());

      // Set presentation error message.
      if(ex.GetMsgId().compare(MoneyControllerException::ERR_CREATE_TICKET)==0)
      {
        m_PresentationStatus = PresentationStatusMessage::TICKET_STATUS_FAILED;
        m_PresentationErrorMessage = PresentationStatusMessage::TICKET_ERR_MSG_FAILED;
      }
      else if(ex.GetMsgId().compare(MoneyControllerException::ERR_TITO)==0)
      {
        m_PresentationStatus = PresentationStatusMessage::TITO_STATUS_FAILED;
        m_PresentationErrorMessage = PresentationStatusMessage::TITO_ERR_MSG_FAILED;
      }
      else if(ex.GetMsgId().compare(MoneyControllerException::ERR_TRANSFER_MONEY)==0)
      {
        m_PresentationStatus = PresentationStatusMessage::TRANSFER_MONEY_STATUS;
        m_PresentationErrorMessage = PresentationStatusMessage::TICKET_ERR_MSG_FAILED;
      }
      throw VLTControllerException(VLTControllerException::ERR_CASHOUT);
    }
    catch(TicketServiceException& ex)
    {
      LOG4CXX_ERROR(s_Log, ex.GetMsgId());
      m_PresentationStatus = PresentationStatusMessage::TICKET_STATUS_FAILED;
      m_PresentationErrorMessage = PresentationStatusMessage::TICKET_ERR_MSG_FAILED;
      throw VLTControllerException(VLTControllerException::ERR_CASHOUT);
    }
    catch(VLTPrinterException& ex)
    {
      LOG4CXX_ERROR(s_Log, ex.GetMsgId());
      m_PresentationStatus = PresentationStatusMessage::PRINTER_STATUS_FAILED;
      m_PresentationErrorMessage = PresentationStatusMessage::PRINTER_ERR_MSG_FAILED;
      throw VLTControllerException(VLTControllerException::ERR_CASHOUT);
    }
  }

  PresentationStatusMessagePtr Controller::CheckPresentationMessageStatus()
  {
    m_PresentationStatusMessagePtr->SetStatusCode(m_PresentationStatus);
    m_PresentationStatusMessagePtr->SetErrorMessage(m_PresentationErrorMessage);

    if(m_PresentationStatus.compare(PresentationStatusMessage::STATUS_SUCCESS)!=0)
    {
      m_PresentationStatus = PresentationStatusMessage::STATUS_SUCCESS;
      m_PresentationErrorMessage = "";
      LOG4CXX_INFO(s_Log, "PresentationStuatus : " << m_PresentationStatusMessagePtr->GetStatusCode());
    }

    return m_PresentationStatusMessagePtr;
  }


  void Controller::KeyboardCallbackFunction(string input)
  {
    if(input.compare(KeyMapLower[KEY_ENTER])==0)
    {
      LOG4CXX_INFO(s_Log, "FIRE: " << m_BarcodeInput.str());
      AddEvent(BarcodeEvent);
    }
    else
    {
      m_BarcodeInput << input;
    }
  }

  string Controller::PlayerGame(const string& sessionToken, const string& clientIp, const string& gameId, const string& realPlay)
  {
    string response;

    try
    {
      ApplicationServices::PlayerPortalFacade::PlayerGameRequest playerGameRequest;
      playerGameRequest.SetSecureToken(sessionToken);
      playerGameRequest.SetClientIp(clientIp);
      playerGameRequest.SetGameId(gameId);
      playerGameRequest.SetRealPlay(realPlay);

      response = m_IProdGameServiceClientPtr->PlayerGame(playerGameRequest);
    }
    catch(PlayerPortalException& ex)
    {
      LOG4CXX_ERROR(s_Log, ex.GetMsgId());
    }

    return response;
  }

  void Controller::RedeemTicket()
  {

    try
    {
      m_IMoneyControllerPtr->RedeemTicket(m_BarcodeInput.str());
    }
    catch(MoneyControllerException& e)
    {
      if(e.GetMsgId().compare(MoneyControllerException::ERR_TITO))
      {
        m_PresentationStatus = PresentationStatusMessage::TITO_STATUS_FAILED;
        m_PresentationErrorMessage = PresentationStatusMessage::TITO_ERR_MSG_FAILED;
      }
      else if(e.GetMsgId().compare(MoneyControllerException::ERR_TICKET_NOT_ACTIVATED))
      {
        m_PresentationStatus = PresentationStatusMessage::TICKET_STATUS_FAILED;
        m_PresentationErrorMessage = PresentationStatusMessage::TICKET_ERR_MSG_FAILED;
      }
      else if(e.GetMsgId().compare(MoneyControllerException::ERR_TRANSFER_MONEY))
      {
        m_PresentationStatus = PresentationStatusMessage::TRANSFER_MONEY_STATUS;
        m_PresentationErrorMessage = PresentationStatusMessage::TRANSFER_MONEY_ERR_MSG_FAILED;
      }
      throw VLTControllerException(VLTControllerException::ERR_REDEEM_TICKET);
    }

  }

  void Controller::NavigateToVLTHomePage()
  {
    VLT_METHOD_TRACE(s_Log, "Controller::NavigateToVLTHomePage()");

    try
    {
      m_IPresentationMQSPtr->NavigateToVLTHomePage(m_PlayerDataPtr->GetSiteSessionToken(),
                                                   m_ServiceDataPtr->GetClientIpAddress());
    }
    catch(PresentationServiceException& e)
    {
      LOG4CXX_ERROR(s_Log, e.GetMsgId());
      throw VLTControllerException(VLTControllerException::ERR_NAVIGATE_TO_PAGE);
    }
  }

  void Controller::NavigateToIdlePage()
  {
    VLT_METHOD_TRACE(s_Log, "Controller::NavigateToIdlePage()");

    try
    {
      m_IPresentationMQSPtr->NavigateToIdlePage();
    }
    catch(PresentationServiceException& e)
    {
      LOG4CXX_ERROR(s_Log, e.GetMsgId());
      throw VLTControllerException(VLTControllerException::ERR_NAVIGATE_TO_PAGE);
    }
  }

  void Controller::PresentationServiceCallback(MessageType& messageType)
  {

  }

  void Controller::BalanceZeroCallback()
  {
    AddEvent(BalanceZero);
  }


  void Controller::BalanceNotZeroCallback()
  {
    AddEvent(BalanceNotZero);
  }

  void Controller::AddEvent(VLTEvent event)
  {
    LOG4CXX_INFO(s_Log, "Push event to queue. Event = " << event);
    queueEvent.push(event);
  }

  void Controller::RunStateMachine()
  {
    LOG4CXX_INFO(s_Log, "Starting state machine");
    ptime m_StartTime;
    ptime m_EndTime;
    VLTState m_State = Idle;
    VLTEvent m_Event = Reset;
    VLTState m_PreviousState = Idle;
    m_FlagStartStateMachine = true;

    while(m_FlagStartStateMachine)
    {
      if(!queueEvent.empty())
      {
        m_Event = queueEvent.front();
        LOG4CXX_INFO(s_Log, "State = " << m_State);
        LOG4CXX_INFO(s_Log, "Event iz queue : " << m_Event);
        queueEvent.pop();
      }
      else
      {
        m_Event = Reset;
      }

      switch (m_State)
      {
      case Idle:
      {
        switch (m_Event)
        {
        case BarcodeEvent:
        {
          LOG4CXX_INFO(s_Log, "State = Idle, Event = BarcodeEvent");
          try
          {
            m_Keyboard->Disable();
            m_IIdentityControllerPtr->Login();
            RedeemTicket();
            NavigateToVLTHomePage();
            m_State = Operable;
			m_Keyboard->Reset();
          }
          catch(BaseException& e)
          {
            LOG4CXX_ERROR(s_Log, e.GetMsgId());
            m_Keyboard->Reset();
            if(e.GetMsgId().compare(IdentityControllerException::ERR_LOGIN_PLAYER)!=0)
            {
              m_IIdentityControllerPtr->Logout();
            }
          }
          m_Keyboard->Enable();
          break;
        }
        case BalanceZero:
        {
          LOG4CXX_INFO(s_Log, "State = Idle, Event = BalanceZero");
          m_State = Idle;
          break;
        }
        case BalanceNotZero:
        {
          try
          {
            m_IIdentityControllerPtr->Login();
            NavigateToVLTHomePage();
            m_State = Operable;
          }
          catch(BaseException& e)
          {
            LOG4CXX_ERROR(s_Log, e.GetMsgId());
          }
          break;
        }
        }
        m_PreviousState = Idle;
        m_Event = Reset;
        break;
      }
      case Operable:
      {
        switch (m_Event)
        {
        case BarcodeEvent:
        {
          LOG4CXX_INFO(s_Log, "State = Operable, Event = BarcodeEvent");
          try
          {
            m_Keyboard->Disable();
            RedeemTicket();
			m_Keyboard->Reset();
          }
          catch(BaseException &e)
          {
		    m_Keyboard->Reset();
            LOG4CXX_ERROR(s_Log, e.GetMsgId());
          }
          m_Keyboard->Enable();
          break;
        }
        case BalanceZero:
        {
          LOG4CXX_INFO(s_Log, "State = Operable, Event = BalanceZero");
          m_State = WaitingForCredit;
          m_StartTime = second_clock::universal_time();
          m_EndTime = m_StartTime + seconds(m_WaitingForCreditMinutes*60);
          break;
        }
        case BalanceNotZero:
        {
          LOG4CXX_INFO(s_Log, "State = Operable, Event = BalanceNotZero");
          m_State = Operable;
          break;
        }
        case CashoutEvent:
        {
          LOG4CXX_INFO(s_Log, "State = Operable, Event = CashoutEvent");
          try
          {
            sleep(2);
            NavigateToIdlePage();
            m_IIdentityControllerPtr->Logout();
            m_State = Idle;
          }
          catch(BaseException &e)
          {
            LOG4CXX_ERROR(s_Log, e.GetMsgId());
          }
          break;
        }
        }
        m_PreviousState = Operable;
        m_Event = Reset;
        break;
      }

      case WaitingForCredit:
      {
        switch (m_Event)
        {
        case BarcodeEvent:
        {
          LOG4CXX_INFO(s_Log, "State = WaitingForCredit, Event = BarcodeEvent");
          try
          {
            m_State = WaitingForCredit;
            m_Keyboard->Disable();
            RedeemTicket();
			m_Keyboard->Reset();
          }
          catch(BaseException &e)
          {
		    m_Keyboard->Reset();
            LOG4CXX_ERROR(s_Log, e.GetMsgId());
          }
          m_Keyboard->Enable();
          break;
        }
        case BalanceZero:
        {
          LOG4CXX_INFO(s_Log, "State = WaitingForCredit, Event = BalanceZero");
          NavigateToIdlePage();
          m_State = WaitingForCredit;
          break;
        }
        case BalanceNotZero:
        {
          LOG4CXX_INFO(s_Log, "State = WaitingForCredit, Event = BalanceNotZero");
          m_State = Operable;
          break;
        }
        case CashoutEvent:
        {
          LOG4CXX_INFO(s_Log, "State = WaitingForCredit, Event = CashoutEvent");
          try
          {
            sleep(2);
            NavigateToIdlePage();
            m_IIdentityControllerPtr->Logout();
            m_State = Idle;
          }
          catch(BaseException &e)
          {
            LOG4CXX_ERROR(s_Log, e.GetMsgId());
          }
          break;
        }
        }

        if (second_clock::universal_time() > m_EndTime)
        {
          LOG4CXX_INFO(s_Log, "Out of time");
          try
          {
            NavigateToIdlePage();
            m_IIdentityControllerPtr->Logout();
            m_State = Idle;
            m_PreviousState = WaitingForCredit;
          }
          catch(BaseException &e)
          {
            LOG4CXX_ERROR(s_Log, e.GetMsgId());
          }
        }

        m_PreviousState = WaitingForCredit;
        m_Event = Reset;
        break;
        }
      }
      sleep(1);
    }
  }

  void Controller::StopStateMachine()
  {
    m_FlagStartStateMachine = false;
  }

  ControllerPtr Controller::GetThis()
  {
    return shared_from_this();
  }
}
